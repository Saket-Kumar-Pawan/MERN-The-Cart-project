



const Posts = () => {

    return (
        <>Hello</>
    )
}

export default Posts;