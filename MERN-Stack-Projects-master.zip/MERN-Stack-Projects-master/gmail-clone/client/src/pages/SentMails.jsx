



const SendMails = () => {

    return (
        <>Div</>
    )
}

export default SendMails;