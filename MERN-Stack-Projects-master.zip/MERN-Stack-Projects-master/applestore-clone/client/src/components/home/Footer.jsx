


const Footer = () => {
    return (
        <p>lHelo</p>
    )
}

export default Footer;